from math import sqrt, atan2

yaw = atan2(100.00, 300.00)
pitch = atan2(500.00, sqrt(300.00**2 + 100**2))
roll = 0.00

# targetP1 = f"{x_base}, {y_base}, {z_base}, -180.00, 0.0, 135.00"
            



            #targetP1 = "300.00, 100, 500, -180.00, 0.0, 135.00"